#!/usr/bin/env python
# coding: utf-8

# # Supervised Learning: Winsconsin Diagnostic Breast Cancer (WDBC) dataset

# In[1]:


## Import libraries
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.image as mpl
import scipy
import sklearn


# In[2]:


#Load dataset 
Cancer = pd.read_csv(r"C:\Users\Ramatu's PC\Desktop\430pm\Cancerdata.csv")


# In[3]:


# drop the ID column
Cancer.drop(['id'], axis=1, inplace = True)


# In[4]:


#View the first five rows
Cancer.head()


# ## Exploratory Analysis

# In[5]:


#strip() takes out leading and trailing spaces
Cancer.columns.str.strip()


# In[6]:


Cancer.info()


# In[7]:


# New dataframe with only features of means
MeansOnly = Cancer[['radius_mean', 'texture_mean', 'perimeter_mean',
       'area_mean', 'smoothness_mean', 'compactness_mean', 'concavity_mean',
       'concave points_mean', 'symmetry_mean', 'fractal_dimension_mean','diagnosis']]


# In[8]:


#  New dataframe with only features of standard error
seOnly = Cancer[['radius_se', 'texture_se', 'perimeter_se', 'area_se', 'smoothness_se',
       'compactness_se', 'concavity_se', 'concave points_se', 'symmetry_se',
       'fractal_dimension_se','diagnosis']]


# In[9]:


# New dataframe with only features of the worst means (mean of largest 3)
worstMeans = Cancer[['radius_worst', 'texture_worst',
       'perimeter_worst', 'area_worst', 'smoothness_worst',
       'compactness_worst', 'concavity_worst', 'concave points_worst',
       'symmetry_worst', 'fractal_dimension_worst','diagnosis']]


# In[10]:


#View the first 5 rows of the dataframe
MeansOnly.head()


# In[11]:


#get the values count of the binary column
Cancer["diagnosis"].value_counts()


# In[12]:


# Statistical description of the columns in the dataframe
Cancer.describe()


# In[13]:


#plot an Histogram showing the destribution of each feacture
Cancer.hist(bins=50, figsize=(20,15))
plt.show()


# In[14]:


#plot graph showing correlation in the means only dataframe
sns.set()
sns.pairplot(data=MeansOnly, hue='diagnosis',markers=["s", "D"], palette="husl")


# In[15]:


#plot graph showing correlation in the worst-meann only dataframe
sns.pairplot(data=worstMeans , hue='diagnosis',markers=["s", "D"], palette="husl")


# In[16]:


#Build the correlation table
corr = Cancer.corr()


# In[17]:


#show the correlation table
corr


# In[18]:


#Visual representation of the correlation matrix ------Heatmap--------
corr = corr [corr < 1] ## To avoid getting correlation of variable with themselves i.e value of 1 
mask = np.zeros_like(corr)
mask[np.triu_indices_from(mask)] = True
with sns.axes_style("white"):
    f,ax = plt.subplots(figsize=(20, 16))
sns.heatmap(corr, cbar = True,  square = True, annot = True, fmt= '.1f', 
            xticklabels= True, yticklabels= True
            ,cmap="YlGnBu", linewidths=.5, mask = mask, ax=ax)
plt.title('HEATMAP FOR CORRELATION', size=18);


# In[19]:


#Encode the Categorical column
from sklearn.preprocessing import LabelEncoder
encoder = LabelEncoder()
Diagnosis = Cancer["diagnosis"]
Diagnosis_encoded = encoder.fit_transform(Diagnosis)
Cancer["diagnosis"]=Diagnosis_encoded


# In[20]:


print(Cancer.groupby('diagnosis').size())


# # Predictive Analysis

# In[21]:


# Seperate the y from the x columns
X = Cancer.drop('diagnosis',axis=1)
Y = Cancer['diagnosis']

from sklearn.model_selection import train_test_split
X_train, X_validation, Y_train, Y_validation = train_test_split(X, Y, test_size=0.25, random_state=1)
print('--------------- Split-out dataset [Done]')


# Feature Selection

# In[22]:


#Feature Selection ---------Method 1----------
#filter based method ----CHI SQUARED----------

from sklearn.ensemble import ExtraTreesClassifier
from sklearn.feature_selection import SelectFromModel
from sklearn.model_selection import cross_val_score
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import  chi2
from sklearn.preprocessing import MinMaxScaler

X_norm = MinMaxScaler().fit_transform(X)
chi_selector = SelectKBest(chi2, k = 15) # default is k=10 but i want top 16
chi_selector.fit(X_norm, Y)
chi_support = chi_selector.get_support()
chi_feature = X.loc[:,chi_support].columns.tolist()
print(str(len(chi_feature)), 'selected features')


# In[23]:


#Feature Selection -------------------Method 2--------------------
#wrapper based method ----Reccursive feature elimination----------

import warnings
from sklearn.feature_selection import RFE
from sklearn.linear_model import LogisticRegression
from sklearn.exceptions import ConvergenceWarning
warnings.filterwarnings('ignore', category = ConvergenceWarning)
rfe_selector = RFE(estimator=LogisticRegression(solver='lbfgs'), n_features_to_select=15, step=10, verbose=5)
rfe_selector.fit(X_norm, Y)
rfe_support = rfe_selector.get_support()
rfe_feature = X.loc[:,rfe_support].columns.tolist()
print(str(len(rfe_feature)), 'selected features')


# In[24]:


#Feature Selection -------------------Method 3--------------------
#embedded method --------------lasso :selectFromModel-------------
import warnings
from sklearn.feature_selection import SelectFromModel
from sklearn.linear_model import LogisticRegression

embeded_lr_selector = SelectFromModel(estimator = LogisticRegression(penalty="l2",solver='lbfgs'), max_features=18)
embeded_lr_selector.fit(X_norm, Y)

embeded_lr_support = embeded_lr_selector.get_support()
embeded_lr_feature = X.loc[:,embeded_lr_support].columns.tolist()
print(str(len(embeded_lr_feature)), 'selected features')


# In[25]:


# put all selection together
feature_selection_ = pd.DataFrame({'Feature':X.columns,'Chi-2':chi_support,'RFE':rfe_support,  'Logistics':embeded_lr_support})
# count the selected times for each feature
feature_selection_['Total'] = np.sum(feature_selection_, axis=1)
# display all 30
feature_selection_ = feature_selection_.sort_values(['Total','Feature'] , ascending=False)
feature_selection_.index = range(1, len(feature_selection_)+1)
feature_selection_


# In[26]:


# Chosing top 15 features from the feature selection dataframe
Cancer_fs = Cancer[['radius_worst', 'radius_se', 'radius_mean', 'perimeter_worst', 'perimeter_mean','concavity_worst', 'concavity_mean', 
              'concave points_worst',  'concave points_mean', 'area_worst', 'area_mean', 'texture_worst', 'texture_mean',
              'symmetry_worst', 'smoothness_worst', 'diagnosis' ]]
Cancer_fs.head()


# In[27]:


# Seperate the y from the x columns from selected features
X_fs = Cancer_fs.drop('diagnosis',axis=1)
Y_fs = Cancer_fs['diagnosis']

from sklearn.model_selection import train_test_split
X_train_fs, X_test_fs, Y_train_fs, Y_test_fs = train_test_split(X_fs, Y_fs, test_size=0.25, random_state=1)
print('--------------- Split-out dataset [Done]')


# In[28]:


#comparing the new size of the feature selected dataframe to the original--------training set only------
print("X_train.shape: {}".format(X_train.shape))
print("X_train_fs.shape: {}".format(X_train_fs.shape))


# Desicision Tree Classifier

# In[29]:


from sklearn.model_selection import RandomizedSearchCV
from time import time
from scipy.stats import randint
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
#build a classifier
clf_fs = DecisionTreeClassifier(random_state=0)

#scaling 
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train_fs.astype(np.float64))
X_test_scaled = scaler.transform(X_test_fs.astype(np.float64))
clf_fs.fit(X_train_scaled, Y_train_fs)

y_pred_fs = clf_fs.predict(X_test_scaled)

print("Accuracy: {:.3f}".format(accuracy_score(y_pred_fs, Y_test_fs)))

scores_cv_fs = cross_val_score(clf_fs, X_train_scaled, Y_train_fs, cv=5)
print("mean: {:.3f} (std: {:.3f})".format(scores_cv_fs.mean(),
                                          scores_cv_fs.std()),
                                          end="\n\n" )

print('Misclassified examples: %d' % (Y_test_fs != y_pred_fs).sum())
print('Misclassification rate: %.3f' % ((Y_test_fs != y_pred_fs).sum()/y_pred_fs.sum()) + ' %')
print("Test set Accuracy: {:.3f}".format(clf_fs.score(X_test_scaled, Y_test_fs)))
print("Training set Accuracy: {:.3f}".format(clf_fs.score(X_train_scaled, Y_train_fs)))
print('--------------- DecisionTreeClassifier --No Parameter specification-- : classifier.fit [Done]')


# In[61]:


#View the decision tree -----------Before Pruning-----------

import os
import graphviz
os.environ['PATH'] = os.environ['PATH']+';'+os.environ['CONDA_PREFIX']+r'\library\bin\graphviz'

from IPython.display import Image
from pydotplus import graph_from_dot_data
from sklearn.tree import export_graphviz

from sklearn.tree import DecisionTreeClassifier, tree
tree_graph = tree.DecisionTreeClassifier(random_state=0)

tree_graph.fit(X_train_fs, Y_train_fs)

dot_data = export_graphviz(tree_graph, class_names= ['Malignant', 'Benign'], feature_names = ['radius_worst', 'radius_se', 'radius_mean', 'perimeter_worst', 'perimeter_mean','concavity_worst', 'concavity_mean', 
              'concave points_worst',  'concave points_mean', 'area_worst', 'area_mean', 'texture_worst', 'texture_mean',
              'symmetry_worst', 'smoothness_worst'],rounded=True, filled=True, out_file = None)

graph = graph_from_dot_data(dot_data)
graph.write_png('Before_Pruning.png')


# In[60]:


#view classification report and confusion matrix
print ("----------------------> [DecisionTreeClassifier]")
from sklearn.metrics import classification_report, confusion_matrix
print(confusion_matrix(Y_test_fs,y_pred_fs))
print(classification_report(Y_test_fs,y_pred_fs))


# In[32]:


#plot of confusion matrix
from sklearn.metrics import confusion_matrix
plt.figure(figsize=(4,3))
cm =confusion_matrix(Y_test_fs, y_pred_fs)
sns.heatmap(cm,annot=True, cmap="Blues", fmt="d", 
            xticklabels = ['Benign', 'Malignant'], 
            yticklabels = ['Benign', 'Malignant'])
plt.ylabel('True')
plt.xlabel('Predicted')
plt.title("Confusion Matrix for Decision Tree before pruning");


# In[56]:


#prunning----Parameter Selection: The tree will be pruned with the highest ranking parameters---------
# Ranks parameters combination and assigns 3 rankings based on validation score
# Utility function to report best scores
def report(results, n_top=3):
    for i in range(1, n_top + 1):
        candidates = np.flatnonzero(results['rank_test_score'] == i)
        for candidate in candidates:
            print("Model with rank: {0}".format(i))
            print("Mean validation score: {0:.3f} (std: {1:.3f})"
                  .format(results['mean_test_score'][candidate],
                          results['std_test_score'][candidate]))
            print("Parameters: {0}".format(results['params'][candidate]))
            print("")


#specify parameters and distributions to sample from 
param_dist = {"max_depth": [3, None], 
              "max_features": randint(1, 9), 
              "min_samples_leaf": randint(1, 9), 
              "criterion": ["gini", "entropy"]} 
#run randomized search
n_iter_search = 100
random_search = RandomizedSearchCV(clf_fs, param_distributions=param_dist,
                                   n_iter=n_iter_search, cv = 10, iid = False)

start = time()
random_search.fit(X_fs, Y_fs)
print("RandomizedSearchCV took %.2f seconds for %d candidates"
      " parameter settings." % ((time() - start), n_iter_search))
report(random_search.cv_results_)


# In[57]:


# test the best parameters
from sklearn.metrics import accuracy_score
print("\n\n-- Testing best parameters [Random]...")

clf_fs_p = DecisionTreeClassifier(criterion= 'entropy', max_depth= None, 
                                     max_features = 5, min_samples_leaf= 2, min_samples_split = 5, max_leaf_nodes = 6, 
                                     random_state=0)

X_train_p, X_test_p, y_train_p ,y_test_p = train_test_split(X_fs,Y_fs, test_size=0.25, random_state = 33)
clf_fs_p.fit(X_train_p, y_train_p)
#Scaling training set 
scaler = StandardScaler()
X_train_scaled_p = scaler.fit_transform(X_train_p.astype(np.float64))

y_pred_p = clf_fs_p.predict(X_test_p)

print("Accuracy: {:.3f}".format(accuracy_score(y_pred_p, y_test_p)))

scores_cv_fs = cross_val_score(clf_fs_p, X_train_scaled_p, y_train_p, cv=5)
print("mean: {:.3f} (std: {:.3f})".format(scores_cv_fs.mean(),
                                          scores_cv_fs.std()),
                                          end="\n\n" )


# In[58]:


#Using pruning parameters ---------Classification report--------
print ("----------------------> [DecisionTreeClassifier with Pruning]")
from sklearn.metrics import classification_report, confusion_matrix
print(confusion_matrix(y_test_p,y_pred_p))
print(classification_report(y_test_p,y_pred_p))

print('Misclassified examples: %d' % (y_test_p != y_pred_p).sum())
print('Misclassification rate: %.3f' % ((y_test_p != y_pred_p).sum()/y_pred_p.sum()) + ' %')
print("Test set Accuracy: {:.3f}".format(clf_fs_p.score(X_test_p, y_test_p)))
print("Training set Accuracy: {:.3f}".format(clf_fs_p.score(X_train_p, y_train_p)))
print('--------------- DecisionTreeClassifier --Parameters specified-- : classifier.fit [Done]')


# In[36]:


#plot of confusion matrix
from sklearn.metrics import confusion_matrix
plt.figure(figsize=(4,3))
cm =confusion_matrix(y_test_p, clf_fs_p.predict(X_test_p))
sns.heatmap(cm,annot=True, cmap="Blues", fmt="d", 
            xticklabels = ['Benign', 'Malignant'], 
            yticklabels = ['Benign', 'Malignant'])
plt.ylabel('True')
plt.xlabel('Predicted')
plt.title("Confusion Matrix for Decision Tree with Pruning");


# In[62]:


#plot of decision tree after prunning
import os
import graphviz
os.environ['PATH'] = os.environ['PATH']+';'+os.environ['CONDA_PREFIX']+r'\library\bin\graphviz'

from IPython.display import Image
from pydotplus import graph_from_dot_data
from sklearn.tree import export_graphviz

from sklearn.tree import DecisionTreeClassifier, tree
tree_graph_p = tree.DecisionTreeClassifier(criterion= 'entropy', max_depth= None, 
                                     max_features= 5, min_samples_leaf= 2, min_samples_split = 2, max_leaf_nodes= 6, 
                                     random_state=0)

tree_graph_p.fit(X_train_p, y_train_p)

dot_data = export_graphviz(tree_graph_p, class_names= ['Malignant', 'Benign'], feature_names = ['radius_worst', 'radius_se', 'radius_mean', 'perimeter_worst', 'perimeter_mean','concavity_worst', 'concavity_mean', 
              'concave points_worst',  'concave points_mean', 'area_worst', 'area_mean', 'texture_worst', 'texture_mean',
              'symmetry_worst', 'smoothness_worst'],rounded=True, filled=True, out_file = None)

graph = graph_from_dot_data(dot_data)
graph.write_png('After_Pruning.png')


# In[38]:


#Custom function to plot learning curves for tree model ----see reference page in Analysis.pdf for source----

train_sizes = [1, 100, 200, 300, 426]

from sklearn.model_selection import learning_curve

features = X_fs
target = Y_fs

def learning_curves(estimator, data, features, target, train_sizes, cv):
    train_sizes, train_scores, validation_scores = learning_curve(
    estimator, features, target, train_sizes =
    train_sizes,
    cv = cv, scoring = 'neg_mean_squared_error')
    train_scores_mean = -train_scores.mean(axis = 1)
    validation_scores_mean = -validation_scores.mean(axis = 1)

    plt.plot(train_sizes, train_scores_mean, label = 'Training error')
    plt.plot(train_sizes, validation_scores_mean, label = 'Validation error')

    plt.ylabel('MSE', fontsize = 14)
    plt.xlabel('Training set size', fontsize = 14)
    title = 'Learning curves for a ' + str(estimator).split('(')[0] + ' model'
    plt.title(title, fontsize = 18, y = 1.03)
    plt.legend()
    plt.ylim(-1,1)


# In[39]:


### Plotting the two learning curves ###

plt.figure(figsize = (16,5))

for model, i in [(DecisionTreeClassifier(criterion= 'entropy', max_depth= None, 
                                     max_features= 8, min_samples_leaf= 5, min_samples_split = 2, max_leaf_nodes= 6, 
                                     random_state=0), 1), (DecisionTreeClassifier(random_state=0),2)]:
    plt.subplot(1,2,i)
    learning_curves(model, Cancer_fs, features, target, train_sizes, 5)

        


# k-Nearest Neighbors

# In[40]:


from sklearn.neighbors import KNeighborsClassifier
#Find the best k value
Accuracy_training_set = []
Accuracy_testing_set = []

#find the best value for n_neighbors------between 1 and 15------
k = range(1, 15)

#running for loop to fit n_neighbors from 1 - 15
for n_neighbors in k:
    knn= KNeighborsClassifier(n_neighbors=n_neighbors)
    knn.fit(X_train_scaled, Y_train_fs)
    Accuracy_training_set.append(knn.score(X_train_scaled, Y_train_fs))
    Accuracy_testing_set.append(knn.score(X_test_scaled, Y_test_fs))
    
print('--------------- KNeighborsClassifier : classifier.fit [Done]')


# In[41]:


plt.plot(k, Accuracy_training_set, label="Training Set Accuracy")
plt.plot(k, Accuracy_testing_set, label="Test Set Accuracy")
plt.ylabel("Accuracy")
plt.xlabel("n_neighbors")
plt.legend()


# In[42]:


error = []

# Calculating error for K values between 1 and 15
for i in range(1, 15):
    knn = KNeighborsClassifier(n_neighbors=i)
    knn.fit(X_train_scaled, Y_train_fs)
    pred_i = knn.predict(X_test_scaled)
    error.append(np.mean(pred_i != Y_test_fs))

print('--------------- mean error calculation [Done]')


# In[43]:


plt.figure(figsize=(12, 6))
plt.plot(range(1, 15), error, color='red', linestyle='dashed', marker='o',
         markerfacecolor='blue', markersize=10)
plt.title('Error Rate K Value')
plt.xlabel('K Value')


# In[44]:


# From the graph my above analysis the best k value is 8

# build a KNeighborsClassifier using eight neighbor
kNN = KNeighborsClassifier(n_neighbors=8)
kNN.fit(X_train_scaled, Y_train_fs)


# In[45]:


Y_pred_kNN = kNN.predict(X_test_scaled)

print('Misclassified examples: %d' % (Y_test_fs != Y_pred_kNN).sum())
print('Misclassification rate: %.3f' % ((Y_test_fs != Y_pred_kNN).sum()/Y_pred_kNN.sum()) + ' %')
print("Test set Accuracy: {:.3f}".format(kNN.score(X_test_scaled, Y_test_fs)))
print("Training set Accuracy: {:.3f}".format(kNN.score(X_train_scaled, Y_train_fs)))
print('--------------- KNeighborsClassifier : classifier.predict [Done]')


# In[46]:



print ("----------------------> [KNeighborsClassifier]")
print(confusion_matrix(Y_test_fs,Y_pred_kNN))
print(classification_report(Y_test_fs,Y_pred_kNN))


# In[47]:


#plot of confusion matrix
from sklearn.metrics import confusion_matrix
plt.figure(figsize=(4,3))
cm =confusion_matrix(Y_test_fs, kNN.predict(X_test_scaled))
sns.heatmap(cm,annot=True, cmap="Blues", fmt="d", 
            xticklabels = ['Benign', 'Malignant'], 
            yticklabels = ['Benign', 'Malignant'])
plt.ylabel('True')
plt.xlabel('Predicted')
plt.title("Confusion Matrix for KNeighborsClassifier");


# ## Naïve Bayes Algorithm

# In[48]:


##################################### [GaussianNB]
from sklearn.naive_bayes import GaussianNB
classifier = GaussianNB()
classifier.fit(X_train_scaled, Y_train_fs)

print('--------------- GaussianNB : classifier.fit [Done]')


# In[49]:


Y_pred_NB = classifier.predict(X_test_scaled)

print('Misclassified examples: %d' % (Y_test_fs != Y_pred_NB).sum())
print('Misclassification rate: %.3f' % ((Y_test_fs != Y_pred_NB).sum()/Y_pred_NB.sum()) + ' %')
print("Test set Accuracy: {:.3f}".format(classifier.score(X_test_scaled, Y_test_fs)))
print("Training set Accuracy: {:.3f}".format(classifier.score(X_train_scaled, Y_train_fs)))
print('--------------- GaussianNB : classifier.predict [Done]')


# In[50]:


from sklearn.metrics import classification_report, confusion_matrix
print ("----------------------> [GaussianNB]")
print(confusion_matrix(Y_test_fs,Y_pred_NB))
print(classification_report(Y_test_fs,Y_pred_NB))


# In[51]:


#plot of confusion matrix
from sklearn.metrics import confusion_matrix
plt.figure(figsize=(4,3))
cm =confusion_matrix(Y_test_fs, classifier.predict(X_test_scaled))
sns.heatmap(cm,annot=True, cmap="Blues", fmt="d", 
            xticklabels = ['Benign', 'Malignant'], 
            yticklabels = ['Benign', 'Malignant'])
plt.ylabel('True')
plt.xlabel('Predicted')
plt.title("Confusion Matrix for GaussianNB");


# In[52]:


import scikitplot as skplt
NB = GaussianNB()
X = X_fs
y = Y_fs
cv = 5
skplt.estimators.plot_learning_curve(NB, X, y, cv=cv)

plt.show()


# In[53]:


# false positive rate,fpr= FP/(TN+FP) OR fpr=1-specificty, tpr=sensitivity 
import sklearn.metrics as metrics

y_pred_DT_BP = clf_fs.predict_proba(X_test_scaled)[::,1]
fpr1, tpr1, _ = metrics.roc_curve(Y_test_fs,  y_pred_DT_BP)
auc1 = metrics.roc_auc_score(Y_test_fs, y_pred_DT_BP)

y_pred_DT_AP = clf_fs_p.predict_proba(X_test_p)[::,1]
fpr2, tpr2, _ = metrics.roc_curve(y_test_p,  y_pred_DT_AP)
auc2 = metrics.roc_auc_score(y_test_p,y_pred_DT_AP)

y_pred_DT_kNN =  kNN.predict_proba(X_test_scaled)[::,1]
fpr3, tpr3, _ = metrics.roc_curve(Y_test_fs,  y_pred_DT_kNN)
auc3 = metrics.roc_auc_score(Y_test_fs, y_pred_DT_kNN)

y_pred_DT_NB = classifier.fit(X_train_scaled, Y_train_fs).predict(X_test_scaled)
fpr4, tpr4, _ = metrics.roc_curve(Y_test_fs,  y_pred_DT_NB)
auc4 = metrics.roc_auc_score(Y_test_fs, y_pred_DT_NB)

plt.figure(figsize=(10,7))
plt.plot([0, 1], [0, 1], 'k--')
plt.plot(fpr1,tpr1,label="Decision Tree Before Prunning, auc="+str(round(auc1,2)))
plt.plot(fpr2,tpr2,label="Decision Tree After Prunning, auc="+str(round(auc2,2)))
plt.plot(fpr3,tpr3,label="KNearest Nieghbors, auc="+str(round(auc3,2)))
plt.plot(fpr4,tpr4,label="Gaussian NB, auc="+str(round(auc4,2)))

plt.legend(loc=4, title='Models', facecolor='white')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC', size=15)
plt.box(False)
plt.savefig('ImageName', format='png', dpi=200, transparent=True);


Install Keras Library:
pip Install Keras

Install tensorflow Library:Uses tensoflow backend
pip Install tensorflow

To run this code you need to have keras library installed on your PC.

Other Requirements:
Seaborn Library
Run cell by cell on Jupyter Notebook
Python version: 3.7.2
JupyterLab:1.2.6
Jupyter Notebook:6.0.3
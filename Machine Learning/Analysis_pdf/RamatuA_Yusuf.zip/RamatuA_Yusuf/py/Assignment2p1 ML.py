#!/usr/bin/env python
# coding: utf-8

# # Supervised and Unsuperviced Learning: Winsconsin Diagnostic Breast Cancer (WDBC) dataset

# In[1]:


# ===========================================================================
#                              [Import libraries]
# ===========================================================================
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.image as mpl
import scipy
import sklearn


# In[2]:


# ===========================================================================
#                              [Load dataset]
# ===========================================================================
Cancer = pd.read_csv(r"C:\Users\Ramatu's PC\Desktop\430pm\Cancerdata.csv")


# In[3]:


# ===========================================================================
#                              [DATA CLEANING]
# ===========================================================================
# drop the ID column
Cancer.drop(['id'], axis=1, inplace = True)

#strip() takes out leading and trailing spaces
Cancer.columns.str.strip()

#View the first five rows
Cancer.head()


# In[4]:


# ===========================================================================
#                              [Explore Dataset]
# ===========================================================================
print('Count of data type in dataset')
Cancer.get_dtype_counts()


# In[5]:


print('Shape of dataset')
Cancer.shape


# In[6]:


print('Check dataset for Null Values')
Cancer.isnull().sum() / Cancer.shape[0] 


# In[7]:


print('Get Dataset information')
Cancer.info()
  


# In[8]:


print('Statistical description of the columns in the dataframe')
Cancer.describe()


# In[9]:


print('Get the values count of the binary column')
Cancer["diagnosis"].value_counts()


# In[10]:


# ===========================================================================
#                              [Exploratory Analysis]
# ===========================================================================
print('Plot of Histogram showing the distribution of each feature')
Cancer.hist(bins=50, figsize=(20,15))
plt.show()


# In[11]:


#Build the correlation table
corr = Cancer.corr()
print('Visual representation of the correlation matrix ------Heatmap------')
corr = corr [corr < 1] ## To avoid getting correlation of variable with themselves i.e value of 1 
mask = np.zeros_like(corr)
mask[np.triu_indices_from(mask)] = True
with sns.axes_style("white"):
    f,ax = plt.subplots(figsize=(20, 16))
sns.heatmap(corr, cbar = True,  square = True, annot = True, fmt= '.1f', 
            xticklabels= True, yticklabels= True
            ,cmap="YlGnBu", linewidths=.5, mask = mask, ax=ax)
plt.title('HEATMAP FOR CORRELATION', size=18);


# In[12]:


print('Encode the Categorical column--------[Done]')
from sklearn.preprocessing import LabelEncoder
encoder = LabelEncoder()
Diagnosis = Cancer["diagnosis"]
Diagnosis_encoded = encoder.fit_transform(Diagnosis)
Cancer["diagnosis"]=Diagnosis_encoded


# In[13]:


# ===========================================================================
#                              [Predictive Analysis]
# ===========================================================================
# Seperate the y from the x columns
X = Cancer.drop('diagnosis',axis=1)
Y = Cancer['diagnosis']

from sklearn.model_selection import train_test_split
X_train, X_validation, y_train, y_validation = train_test_split(X, Y, test_size=0.30, random_state=1)
print('--------------- Split-out dataset [Done]')


# In[14]:


print('Applying dimensionality Reduction using Principal Component Analysis [PCA]')
import matplotlib.pyplot as plt
from sklearn import datasets
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.model_selection import GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier

#Define Pipeline
pca = PCA()
#Define normalization using standard scaler
scaler = StandardScaler()
#Define model
model1 = DecisionTreeClassifier(random_state=0)

pipe_dt = Pipeline(steps=[('s', scaler), ('pca', pca), ('m', model1)])


# set parameters of pipelines using ‘__’ separated parameter names:

param_grid = {"pca__n_components":[5, 10, 15, 20, 30],
              "m__criterion": ["gini", "entropy"],
              "m__min_samples_split": [2, 10, 20],
              "m__max_depth": [None, 2, 5, 10],
              "m__min_samples_leaf": [1, 5, 10],
              "m__max_leaf_nodes": [None, 5, 10, 20],
              }

search = GridSearchCV(pipe_dt, param_grid, n_jobs=-1)

#fit the Gridsearch
clf_dt = search.fit(X_train, y_train)
#Get Best Parameters
print("Best parameter (CV score=%0.3f):" % search.best_score_)
print(search.best_params_)

# Plot the PCA spectrum
pca.fit(X_train)

#plot
fig, (ax0, ax1) = plt.subplots(nrows=2, sharex=True, figsize=(6, 6))
ax0.plot(np.arange(1, pca.n_components_ + 1),
         pca.explained_variance_ratio_, '+', linewidth=2)
ax0.set_ylabel('PCA explained variance ratio')

ax0.axvline(search.best_estimator_.named_steps['pca'].n_components,
            linestyle=':', label='n_components chosen')
ax0.legend(prop=dict(size=12))

# For each number of components, find the best classifier results
results = pd.DataFrame(search.cv_results_)
components_col = 'param_pca__n_components'
best_clfs = results.groupby(components_col).apply(
    lambda g: g.nlargest(1, 'mean_test_score'))

best_clfs.plot(x=components_col, y='mean_test_score', yerr='std_test_score',
               legend=False, ax=ax1)
ax1.set_ylabel('Classification accuracy (val)')
ax1.set_xlabel('n_components')

plt.xlim(-1, 35)

plt.tight_layout()
plt.show()


# In[15]:


#----------Test Best Parameters---------
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import RepeatedStratifiedKFold
from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report, confusion_matrix
from time import time
t0 = time()
clf_dt =clf_dt.best_estimator_
y_pred_dt = clf_dt.predict(X_validation)
print("done in %0.3fs" % (time() - t0))
cv = RepeatedStratifiedKFold(n_splits=10, n_repeats=3, random_state=1)
scores_cv_dt = cross_val_score(clf_dt, X_train, y_train, cv=cv)

scores = cross_val_score(clf_dt, X_validation, y_validation, scoring='roc_auc', cv=cv, n_jobs=-1)


# In[16]:


#---------Classification report--------
print ("----------------------> [DecisionTreeClassifier performance summary]")
print("Accuracy: {:.3f}".format(accuracy_score(y_pred_dt, y_validation)))
print("mean: {:.3f} (std: {:.3f})".format(scores_cv_dt.mean(),
                                          scores_cv_dt.std()),
                                          end="\n\n" )
print(confusion_matrix(y_validation,y_pred_dt))
print(classification_report(y_validation,y_pred_dt))
print('Mean ROC AUC: %.3f' % scores.mean(), end="\n\n")
print('Misclassified examples: %d' % (y_validation != y_pred_dt).sum())
print('Misclassification/Error rate: %.3f' % ((y_validation != y_pred_dt).sum()/y_pred_dt.sum()) + ' %')
print("Test set Accuracy: {:.3f}".format(clf_dt.score(X_validation, y_validation)))
print("Training set Accuracy: {:.3f}".format(clf_dt.score(X_train, y_train)))
print('--------------- DecisionTreeClassifier --Parameters specified-- : classifier.fit [Done]')


# In[17]:


#plot of confusion matrix
plt.figure(figsize=(4,3))
cm =confusion_matrix(y_validation, y_pred_dt)
sns.heatmap(cm,annot=True, cmap="Blues", fmt="d", 
            xticklabels = ['Benign', 'Malignant'], 
            yticklabels = ['Benign', 'Malignant'])
plt.ylabel('True')
plt.xlabel('Predicted')
plt.title("Confusion Matrix for Decision Tree Using PCA");


# In[18]:


from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn import metrics
import matplotlib.pyplot as plt


FIG_SIZE = (10, 7)
# Fit to data and predict using pipelined scaling, GNB and PCA.
pipe_dt.fit(X_train, y_train)
pred_test_std = pipe_dt.predict(X_validation)

# Show prediction accuracies in scaled and unscaled data.
print('\nPrediction accuracy for the standardized test dataset with PCA --DT')
print('{:.2%}\n'.format(metrics.accuracy_score(y_validation, pred_test_std)))

# Extract PCA from pipeline
pca_std = pipe_dt.named_steps['pca']

# Show first principal components
print('\nPC 1 with:\n', pca_std.components_[0])
print('\nPC 2 with:\n', pca_std.components_[1])
# Use PCA without and with scale on X_train data for visualization.
scaler = pipe_dt.named_steps['s']
X_train_std_transformed = pca_std.transform(scaler.transform(X_train))

# visualize standardized vs. untouched dataset with PCA performed
fig, ax = plt.subplots()

for l, c, m in zip(range(0, 2), ('blue', 'red'), ('^', 's')):
    ax.scatter(X_train_std_transformed[y_train == l, 0],
                X_train_std_transformed[y_train == l, 1],
                color=c,
                label='class %s' % l,
                alpha=0.5,
                marker=m
                )

ax.set_title('Standardized training dataset after PCA')
ax.set_xlabel('1st principal component')
ax.set_ylabel('2nd principal component')
ax.legend(loc='upper right')
ax.grid()

plt.tight_layout()

plt.show()


# In[19]:


print('Applying dimensionality Reduction using Principal Component Analysis [PCA]')
from sklearn.neighbors import KNeighborsClassifier as KNN

#Define Pipeline
pca = PCA()
#Define normalization using standard scaler
scaler = StandardScaler()
#Define model
model2 = KNN()

pipe_knn = Pipeline(steps=[('s', scaler), ('pca', pca), ('m', model2)])


# set parameters of pipelines using ‘__’ separated parameter names:

param_grid  = {"pca__n_components": [2,5,10,15,20,30],
              'm__n_neighbors' : range(1, 15)}

search = GridSearchCV(pipe_knn, param_grid, n_jobs=-1)

#fit the Gridsearch
clf_knn = search.fit(X_train, y_train)
#Get Best Parameters
print("Best parameter (CV score=%0.3f):" % search.best_score_)
print(search.best_params_)

# Plot the PCA spectrum
pca.fit(X_train)

#plot
fig, (ax0, ax1) = plt.subplots(nrows=2, sharex=True, figsize=(6, 6))
ax0.plot(np.arange(1, pca.n_components_ + 1),
         pca.explained_variance_ratio_, '+', linewidth=2)
ax0.set_ylabel('PCA explained variance ratio')

ax0.axvline(search.best_estimator_.named_steps['pca'].n_components,
            linestyle=':', label='n_components chosen')
ax0.legend(prop=dict(size=12))

# For each number of components, find the best classifier results
results = pd.DataFrame(search.cv_results_)
components_col = 'param_pca__n_components'
best_clfs = results.groupby(components_col).apply(
    lambda g: g.nlargest(1, 'mean_test_score'))

best_clfs.plot(x=components_col, y='mean_test_score', yerr='std_test_score',
               legend=False, ax=ax1)
ax1.set_ylabel('Classification accuracy (val)')
ax1.set_xlabel('n_components')

plt.xlim(-1, 35)

plt.tight_layout()
plt.show()


# In[20]:


#----------Test Best Parameters---------
t0 = time()
clf_knn =clf_knn.best_estimator_
y_pred_knn = clf_knn.predict(X_validation)
print("done in %0.3fs" % (time() - t0))
cv = RepeatedStratifiedKFold(n_splits=10, n_repeats=3, random_state=1)
scores_cv_knn = cross_val_score(clf_knn, X_train, y_train, cv=cv)

scores = cross_val_score(clf_knn, X_validation, y_validation, scoring='roc_auc', cv=cv, n_jobs=-1)


# In[21]:


#---------Classification report--------
print ("----------------------> [KNearestNeighbor performance summary]")
print("Accuracy: {:.3f}".format(accuracy_score(y_pred_knn, y_validation)))
print("mean: {:.3f} (std: {:.3f})".format(scores_cv_knn.mean(),
                                          scores_cv_knn.std()),
                                          end="\n\n" )
print(confusion_matrix(y_validation,y_pred_knn))
print(classification_report(y_validation,y_pred_knn))
print('Mean ROC AUC: %.3f' % scores.mean(), end="\n\n")
print('Misclassified examples: %d' % (y_validation != y_pred_knn).sum())
print('Misclassification/Error rate: %.3f' % ((y_validation != y_pred_knn).sum()/y_pred_knn.sum()) + ' %')
print("Test set Accuracy: {:.3f}".format(clf_knn.score(X_validation, y_validation)))
print("Training set Accuracy: {:.3f}".format(clf_knn.score(X_train, y_train)))
print('--------------- KNearestNeighbor --Parameters specified-- : classifier.fit [Done]')


# In[22]:


#plot of confusion matrix
plt.figure(figsize=(4,3))
cm =confusion_matrix(y_validation, y_pred_knn)
sns.heatmap(cm,annot=True, cmap="Blues", fmt="d", 
            xticklabels = ['Benign', 'Malignant'], 
            yticklabels = ['Benign', 'Malignant'])
plt.ylabel('True')
plt.xlabel('Predicted')
plt.title("Confusion Matrix for KNearestNeighbour Using PCA");


# In[23]:


FIG_SIZE = (10, 7)
# Fit to data and predict using pipelined scaling, GNB and PCA.
pipe_knn.fit(X_train, y_train)
pred_test_std = pipe_knn.predict(X_validation)

# Show prediction accuracies in scaled and unscaled data.
print('\nPrediction accuracy for the standardized test dataset with PCA -KNN')
print('{:.2%}\n'.format(metrics.accuracy_score(y_validation, pred_test_std)))

# Extract PCA from pipeline
pca_std = pipe_knn.named_steps['pca']

# Show first principal components
print('\nPC 1 with:\n', pca_std.components_[0])
print('\nPC 2 with:\n', pca_std.components_[1])
# Use PCA without and with scale on X_train data for visualization.
scaler = pipe_knn.named_steps['s']
X_train_std_transformed = pca_std.transform(scaler.transform(X_train))

# visualize standardized vs. untouched dataset with PCA performed
fig, ax = plt.subplots()

for l, c, m in zip(range(0, 2), ('blue', 'red'), ('^', 's')):
    ax.scatter(X_train_std_transformed[y_train == l, 0],
                X_train_std_transformed[y_train == l, 1],
                color=c,
                label='class %s' % l,
                alpha=0.5,
                marker=m
                )

ax.set_title('Standardized training dataset after PCA')
ax.set_xlabel('1st principal component')
ax.set_ylabel('2nd principal component')
ax.legend(loc='upper right')
ax.grid()

plt.tight_layout()

plt.show()


# In[24]:


print('Applying dimensionality Reduction using Principal Component Analysis [PCA]')
from sklearn.naive_bayes import GaussianNB


#Define Pipeline
pca = PCA()
#Define normalization using standard scaler
scaler = StandardScaler()
#Define model
model3 = GaussianNB()

pipe_NB = Pipeline(steps=[('s', scaler), ('pca', pca), ('m', model3)])


# set parameters of pipelines using ‘__’ separated parameter names:

param_grid = {"pca__n_components": [2,5,10,15,20,30],
              }


search = GridSearchCV(pipe_NB, param_grid, n_jobs=-1)

#fit the Gridsearch
clf_NB = search.fit(X_train, y_train)
#Get Best Parameters
print("Best parameter NB (CV score=%0.3f):" % search.best_score_)
print(search.best_params_)

# Plot the PCA spectrum
pca.fit(X_train)

#plot
fig, (ax0, ax1) = plt.subplots(nrows=2, sharex=True, figsize=(6, 6))
ax0.plot(np.arange(1, pca.n_components_ + 1),
         pca.explained_variance_ratio_, '+', linewidth=2)
ax0.set_ylabel('PCA explained variance ratio')

ax0.axvline(search.best_estimator_.named_steps['pca'].n_components,
            linestyle=':', label='n_components chosen')
ax0.legend(prop=dict(size=12))

# For each number of components, find the best classifier results
results = pd.DataFrame(search.cv_results_)
components_col = 'param_pca__n_components'
best_clfs = results.groupby(components_col).apply(
    lambda g: g.nlargest(1, 'mean_test_score'))

best_clfs.plot(x=components_col, y='mean_test_score', yerr='std_test_score',
               legend=False, ax=ax1)
ax1.set_ylabel('Classification accuracy (val)')
ax1.set_xlabel('n_components')

plt.xlim(-1, 35)

plt.tight_layout()
plt.show()


# In[25]:


#----------Test Best Parameters---------
t0 = time()
clf_NB =clf_NB.best_estimator_
y_pred_NB = clf_NB.predict(X_validation)
print("Done in %0.3fs" % (time() - t0))
cv = RepeatedStratifiedKFold(n_splits=10, n_repeats=3, random_state=1)
scores_cv_NB = cross_val_score(clf_NB, X_train, y_train, cv=cv)

scores = cross_val_score(clf_NB, X_validation, y_validation, scoring='roc_auc', cv=cv, n_jobs=-1)


# In[26]:


#---------Classification report--------
print ("----------------------> [Naive Bayes Classifier performance summary]")
print("Accuracy: {:.3f}".format(accuracy_score(y_pred_NB, y_validation)))
print("mean: {:.3f} (std: {:.3f})".format(scores_cv_NB.mean(),
                                          scores_cv_NB.std()),
                                          end="\n\n" )
print(confusion_matrix(y_validation,y_pred_NB))
print(classification_report(y_validation,y_pred_NB))
print('Mean ROC AUC: %.3f' % scores.mean(), end="\n\n")
print('Misclassified examples: %d' % (y_validation != y_pred_NB).sum())
print('Misclassification/Error rate: %.3f' % ((y_validation != y_pred_NB).sum()/y_pred_NB.sum()) + ' %')
print("Test set Accuracy: {:.3f}".format(clf_NB.score(X_validation, y_validation)))
print("Training set Accuracy: {:.3f}".format(clf_NB.score(X_train, y_train)))
print('--------------- Naive Bayes Classifier --Parameters specified-- : classifier.fit [Done]')


# In[27]:


#plot of confusion matrix
plt.figure(figsize=(4,3))
cm =confusion_matrix(y_validation, y_pred_NB)
sns.heatmap(cm,annot=True, cmap="Blues", fmt="d", 
            xticklabels = ['Benign', 'Malignant'], 
            yticklabels = ['Benign', 'Malignant'])
plt.ylabel('True')
plt.xlabel('Predicted')
plt.title("Confusion Matrix for Naive Bayes Using PCA");


# In[28]:


FIG_SIZE = (10, 7)
# Fit to data and predict using pipelined scaling, GNB and PCA.
pipe_NB.fit(X_train, y_train)
pred_test_std = pipe_NB.predict(X_validation)

# Show prediction accuracies in scaled and unscaled data.
print('\nPrediction accuracy for the standardized test dataset with PCA -NB')
print('{:.2%}\n'.format(metrics.accuracy_score(y_validation, pred_test_std)))

# Extract PCA from pipeline
pca_std = pipe_NB.named_steps['pca']

# Show first principal components
print('\nPC 1 with:\n', pca_std.components_[0])
print('\nPC 2 with:\n', pca_std.components_[1])
# Use PCA without and with scale on X_train data for visualization.
scaler = pipe_NB.named_steps['s']
X_train_std_transformed = pca_std.transform(scaler.transform(X_train))

# visualize standardized vs. untouched dataset with PCA performed
fig, ax = plt.subplots()

for l, c, m in zip(range(0, 2), ('blue', 'red'), ('^', 's')):
    ax.scatter(X_train_std_transformed[y_train == l, 0],
                X_train_std_transformed[y_train == l, 1],
                color=c,
                label='class %s' % l,
                alpha=0.5,
                marker=m
                )

ax.set_title('Standardized training dataset after PCA')
ax.set_xlabel('1st principal component')
ax.set_ylabel('2nd principal component')
ax.legend(loc='upper right')
ax.grid()

plt.tight_layout()

plt.show()


# In[29]:


print('Applying dimensionality Reduction using Principal Component Analysis [PCA]')
from sklearn.svm import SVC

#Define Pipeline
pca = PCA()
#Define normalization using standard scaler
scaler = StandardScaler()
#Define model
model4 = SVC(probability=True)

pipe_svc = Pipeline(steps=[('s', scaler), ('pca', pca), ('m', model4)])


# set parameters of pipelines using ‘__’ separated parameter names:
param_grid = [{"pca__n_components": [2,5,10,15,20,30],
              'm__kernel': ['rbf'], 'm__gamma': [1e-3, 1e-4],
              'm__C': [1, 10,100,1000]},
              {'m__kernel': ['linear'], 'm__C': [1, 10,100,1000]}]

search = GridSearchCV(pipe_svc, param_grid, n_jobs=-1)

#fit the Gridsearch
clf_svc = search.fit(X_train, y_train)
#Get Best Parameters
print("Best parameter (CV score=%0.3f):" % search.best_score_)
print(search.best_params_)

# Plot the PCA spectrum
pca.fit(X_train)

#plot
fig, (ax0, ax1) = plt.subplots(nrows=2, sharex=True, figsize=(6, 6))
ax0.plot(np.arange(1, pca.n_components_ + 1),
         pca.explained_variance_ratio_, '+', linewidth=2)
ax0.set_ylabel('PCA explained variance ratio')

ax0.axvline(search.best_estimator_.named_steps['pca'].n_components,
            linestyle=':', label='n_components chosen')
ax0.legend(prop=dict(size=12))

# For each number of components, find the best classifier results
results = pd.DataFrame(search.cv_results_)
components_col = 'param_pca__n_components'
best_clfs = results.groupby(components_col).apply(
    lambda g: g.nlargest(1, 'mean_test_score'))

best_clfs.plot(x=components_col, y='mean_test_score', yerr='std_test_score',
               legend=False, ax=ax1)
ax1.set_ylabel('Classification accuracy (val)')
ax1.set_xlabel('n_components')

plt.xlim(-1, 35)

plt.tight_layout()
plt.show()


# In[30]:


#----------Test Best Parameters---------
t0 = time()
clf_svc =clf_svc.best_estimator_
y_pred_svc = clf_svc.predict(X_validation)
print("Done in %0.3fs" % (time() - t0))
cv = RepeatedStratifiedKFold(n_splits=10, n_repeats=3, random_state=1)
scores_cv_svc = cross_val_score(clf_svc, X_train, y_train, cv=cv)

scores = cross_val_score(clf_svc, X_validation, y_validation, scoring='roc_auc', cv=cv, n_jobs=-1)


# In[31]:


#---------Classification report--------
print ("----------------------> [Support Vector performance summary]")
print("Accuracy: {:.3f}".format(accuracy_score(y_pred_svc, y_validation)))
print("mean: {:.3f} (std: {:.3f})".format(scores_cv_svc.mean(),
                                          scores_cv_svc.std()),
                                          end="\n\n" )
print(confusion_matrix(y_validation,y_pred_svc))
print(classification_report(y_validation,y_pred_svc))
print('Mean ROC AUC: %.3f' % scores.mean(), end="\n\n")
print('Misclassified examples: %d' % (y_validation != y_pred_svc).sum())
print('Misclassification/Error rate: %.3f' % ((y_validation != y_pred_svc).sum()/y_pred_svc.sum()) + ' %')
print("Test set Accuracy: {:.3f}".format(clf_svc.score(X_validation, y_validation)))
print("Training set Accuracy: {:.3f}".format(clf_svc.score(X_train, y_train)))
print('--------------- Support Vector Classifier --Parameters specified-- : classifier.fit [Done]')


# In[32]:


#plot of confusion matrix
plt.figure(figsize=(4,3))
cm =confusion_matrix(y_validation, y_pred_svc)
sns.heatmap(cm,annot=True, cmap="Blues", fmt="d", 
            xticklabels = ['Benign', 'Malignant'], 
            yticklabels = ['Benign', 'Malignant'])
plt.ylabel('True')
plt.xlabel('Predicted')
plt.title("Confusion Matrix for Support Vectore Using PCA");


# In[33]:


FIG_SIZE = (10, 7)
# Fit to data and predict using pipelined scaling, GNB and PCA.
pipe_svc.fit(X_train, y_train)
pred_test_std = pipe_svc.predict(X_validation)

# Show prediction accuracies in scaled and unscaled data.
print('\nPrediction accuracy for the standardized test dataset with PCA -SVC')
print('{:.2%}\n'.format(metrics.accuracy_score(y_validation, pred_test_std)))

# Extract PCA from pipeline
pca_std = pipe_svc.named_steps['pca']

# Show first principal components
print('\nPC 1 with:\n', pca_std.components_[0])
print('\nPC 2 with:\n', pca_std.components_[1])
# Use PCA without and with scale on X_train data for visualization.
scaler = pipe_svc.named_steps['s']
X_train_std_transformed = pca_std.transform(scaler.transform(X_train))

# visualize standardized vs. untouched dataset with PCA performed
fig, ax = plt.subplots()

for l, c, m in zip(range(0, 2), ('blue', 'red'), ('^', 's')):
    ax.scatter(X_train_std_transformed[y_train == l, 0],
                X_train_std_transformed[y_train == l, 1],
                color=c,
                label='class %s' % l,
                alpha=0.5,
                marker=m
                )

ax.set_title('Standardized training dataset after PCA')
ax.set_xlabel('1st principal component')
ax.set_ylabel('2nd principal component')
ax.legend(loc='upper right')
ax.grid()

plt.tight_layout()

plt.show()


# In[34]:


# false positive rate,fpr= FP/(TN+FP) OR fpr=1-specificty, tpr=sensitivity 
import sklearn.metrics as metrics

y_pred_DT = clf_dt.predict_proba(X_validation)[::,1]
fpr1, tpr1, _ = metrics.roc_curve(y_validation,  y_pred_DT)
auc1 = metrics.roc_auc_score(y_validation, y_pred_DT)

y_pred_kNN =  clf_knn.predict_proba(X_validation)[::,1]
fpr2, tpr2, _ = metrics.roc_curve(y_validation,  y_pred_kNN)
auc2 = metrics.roc_auc_score(y_validation, y_pred_kNN)

y_pred_NB = clf_NB.predict_proba(X_validation)[::,1]
fpr3, tpr3, _ = metrics.roc_curve(y_validation,  y_pred_NB)
auc3 = metrics.roc_auc_score(y_validation, y_pred_NB)

y_pred_svc =  clf_svc.predict_proba(X_validation)[::,1]
fpr4, tpr4, _ = metrics.roc_curve(y_validation,  y_pred_svc)
auc4 = metrics.roc_auc_score(y_validation,y_pred_svc)

plt.figure(figsize=(10,7))
plt.plot([0, 1], [0, 1], 'k--')
plt.plot(fpr1,tpr1,label="Decision Tree with PCA, auc="+str(round(auc1,2)))
plt.plot(fpr2,tpr2,label="KNearest Nieghbors with PCA, auc="+str(round(auc2,2)))
plt.plot(fpr3,tpr3,label="Gaussian NB with PCA, auc="+str(round(auc3,2)))
plt.plot(fpr4,tpr4,label="SVC with PCA, auc="+str(round(auc4,2)))

plt.legend(loc=4, title='Models', facecolor='white')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC', size=15)
plt.box(False)
plt.savefig('ImageName', format='png', dpi=200, transparent=True);


# In[35]:


print('--------------- DecisionTreeClassifier --Learning Curve-- : [Done]')
from yellowbrick.model_selection import LearningCurve
sizes = [1, 100, 200, 300, 426]
# Instantiate the classification model and visualizer

visualizer = LearningCurve(
    clf_dt, cv=cv, scoring='f1_weighted', train_sizes=sizes, n_jobs=4
)

visualizer.fit(X, Y )        # Fit the data to the visualizer
visualizer.show()           # Finalize and render the figure


# In[36]:


print('--------------- KNeighboursClassifier --Learning Curve-- : [Done]')
from yellowbrick.model_selection import LearningCurve
sizes = [1, 100, 200, 300, 426]
# Instantiate the classification model and visualizer

visualizer = LearningCurve(
    clf_knn, cv=cv, scoring='f1_weighted', train_sizes=sizes, n_jobs=4
)

visualizer.fit(X, Y )        # Fit the data to the visualizer
visualizer.show()           # Finalize and render the figure


# In[37]:


print('--------------- Naive Bayes Classifier --Learning Curve-- : [Done]')
from yellowbrick.model_selection import LearningCurve
sizes = [1, 100, 200, 300, 426]
# Instantiate the classification model and visualizer

visualizer = LearningCurve(
    clf_NB, cv=cv, scoring='f1_weighted', train_sizes=sizes, n_jobs=4
)

visualizer.fit(X, Y )        # Fit the data to the visualizer
visualizer.show()           # Finalize and render the figure


# In[38]:


print('--------------- Support Vector Classifier --Learning Curve-- : [Done]')
from yellowbrick.model_selection import LearningCurve
sizes = [1, 100, 200, 300, 426]
# Instantiate the classification model and visualizer

visualizer = LearningCurve(
    clf_svc, cv=cv, scoring='f1_weighted', train_sizes=sizes, n_jobs=4
)

visualizer.fit(X, Y )        # Fit the data to the visualizer
visualizer.show()           # Finalize and render the figure


# In[39]:


# ===========================================================================
#                              [k-means]
# ===========================================================================

# Using scikit-learn to perform K-Means clustering
from sklearn.cluster import KMeans

#scale the dataset using standard scaler
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
scaler.fit(X)
X = scaler.transform(X)

# keep the first ten principal components of the data
pca = PCA(n_components=10, random_state=0)
# fit PCA model to breast cancer data
pca.fit(X)
# transform data onto the first ten principal components
X_pca = pca.transform(X)

# Specify the number of clusters (3) and fit the data X
kmeans = KMeans(n_clusters=3, random_state = 0)
y_kmeans = kmeans.fit_predict(X_pca)
print("Cluster memberships:\n{}".format(y_kmeans))
print("Cluster sizes k-means: {}".format(np.bincount(y_kmeans)))

# Get the cluster centroids
print("Cluster Centers:\n{}".format(kmeans.cluster_centers_))


# In[40]:


Error =[]
for i in range(1, 11):
    kmeans = KMeans(n_clusters = i).fit(X)
    kmeans.fit(X)
    Error.append(kmeans.inertia_)
import matplotlib.pyplot as plt
plt.plot(range(1, 11), Error)
plt.title('Elbow method to find Optimal Number of Clusters')
plt.xlabel('Number of clusters')
plt.ylabel('Error')
plt.show()


# In[41]:


f, (ax1, ax2) = plt.subplots(1, 2, sharey=True,figsize=(10,6))
ax2.set_title("Original")
ax2.scatter(X_pca[:,0],X_pca[:,1],c=Y,cmap='brg')
ax1.set_title('K Means')
ax1.scatter(X_pca[:,0],X_pca[:,1],c=kmeans.labels_,cmap='brg')


# In[ ]:




